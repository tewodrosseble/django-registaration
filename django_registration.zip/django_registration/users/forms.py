from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import UserModel

class UserCreation(UserCreationForm):
    class Meta:
        model = UserModel
        fields = ('username', 'email')

class UserChange(UserChangeForm):
    class Meta:
        model = UserModel
        fields = ('username', 'email')