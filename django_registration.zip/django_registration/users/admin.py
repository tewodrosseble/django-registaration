from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .forms import UserChange, UserCreation
from .models import UserModel

class userAdmin(UserAdmin):
    add_form = UserCreation
    form = UserChange
    model = UserModel
    list_display = ["email", 'username',]

admin.site.register(UserModel, userAdmin)